class Animal
{  
void eat()
{
	System.out.println("eating...");
}  
void bark()
{
	System.out.println("Animal bark");
}
} 

class Dog extends Animal
{  
void bark()
{
	System.out.println("barking...");
}  
} 

class Cat extends Dog
{  
void meow()
{
	System.out.println("meow..");
}  
} 

class Multilevel
{  
public static void main(String args[])
{  
Cat d=new Cat();  
d.meow();  
d.bark();  
d.eat();  
Animal obj=new Animal();
obj.eat();
obj.bark();
Animal sc=new Dog();
sc.bark();
d=(Cat)sc;
d.bark();
}
}