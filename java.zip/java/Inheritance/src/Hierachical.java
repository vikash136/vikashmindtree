class A
{
	public void boss()
	{
		System.out.println(" boss");
	}

}
class B extends A
{
	 public void soni()
	{
		
		System.out.println("soni");
	}
}
class C extends A
{
	void mindtree()
	{
		System.out.println("mindtree");
	}
}
public class Hierachical
{ 
    public static void main(String[] args) 
    { 
        C obj=new C();
        obj.mindtree();
        //obj.soni();
        obj.boss();
    }
}
  



