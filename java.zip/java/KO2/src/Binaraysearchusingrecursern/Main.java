package Binaraysearchusingrecursern;

import java.util.Scanner;

public class Main 
{
		public static int binarySearch(int[] A, int left, int right, int x)
		{
			if (left > right)
			{
				return -1;
			}
			
			int mid = (left + right) / 2;

			if (x == A[mid]) 
			{
				return mid;
			}

			else if (x < A[mid])
			{
				return binarySearch(A, left,  mid - 1, x);
			}

			else
			{
				return binarySearch(A, mid + 1,  right, x);
			}
		}

		public static void main(String[]args)
		{
			Scanner sc=new Scanner (System.in);
			System.out.println("enter the size of array");
			int n=sc.nextInt();
			System.out.println("enter the sorted element ");
			int[] A = new int[n];
			for(int i=0;i<n;i++)
			{
				A[i]=sc.nextInt();
			}
			
			System.out.println("enter the serach which you want ");
			int key=sc.nextInt();
			
			int left = 0;
			int right = A.length - 1;
			int index = binarySearch(A, left, right, key);

			if (index != -1) 
			{
				System.out.println("Element found at index " + index);
			} else
			{
				System.out.println("Element not found in the array");
			}
		}
	}