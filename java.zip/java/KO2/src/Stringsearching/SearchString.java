package Stringsearching;

import java.util.Scanner;

public class SearchString 
{
    public static void main(String[] args) 
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the string size");
        int n=sc.nextInt();
        
        String input[]=new String[n];
        System.out.println("Enter the elements of the array: ");
        for(int i=0;i<input.length;i++)
        {
            input[i]=sc.nextLine();
        }
        
        System.out.print("Enter the element to be found: ");
        String st=sc.nextLine(); 
        for(int i=0;i<n;i++)
		{
			System.out.print(input[i] + " ");
		}
    }
    	public  void  run(int n, String[] input, String st) 
    	{
    		int flag = 0;
    		for(int i=0;i<n;i++)
    		{
    			 if(input[i].equals(st))
    			{
    				flag=1;
    				break;
    			}
    			else
    			{
    				flag=0;
    			}
    		}
    		
    		System.out.println("");
    		  if(flag != 0)  
    		    {  
    		        System.out.println("Item found at location :" + flag);  
    		    }  
    		    else
    		    {
    		        System.out.println(" Item not found ");  
    		        
    		    }
    		
    	}      
    	
        
		
    }