package Result;

public class Order 
{
	private int  order_id;
	private int order_date;
	private String order_name;
	
	public int getOrder_id() 
	{
		return order_id;
	}
	public void setOrder_id(int order_id) 
	{
		this.order_id = order_id;
	}
	public int getOrder_date() 
	{
		return order_date;
	}
	public void setOrder_date(int order_date) 
	{
		this.order_date = order_date;
	}
	public String getOrder_name() 
	{
		return order_name;
	}
	public void setOrder_name(String order_name)
	{
		this.order_name = order_name;
	}
		
}

