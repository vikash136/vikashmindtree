package Result;

import java.util.Scanner;

public class Main
{
	public static void main(String[] args) 
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter 1 for Register \n Enter 2 for show product\nEnter 3 for exit  ");
	int ch=sc.nextInt();
	System.out.println("Enter the number of customer ");
	int n=sc.nextInt();
	Customers a[]=new Customers[n];
	int k=0;
	while(k!=1)
	{
	switch(ch)
	{
	case 1:
	Order b[]=new Order[n];
	for(int i=0;i<n;i++)
	{
		a[i]=new Customers();
		System.out.println("Enter the customer id");
		a[i].setCustomer_id(sc.nextInt());
		
		
		sc.nextLine();
		System.out.println("enter customer name");
		String customer_name=sc.nextLine();
		a[i].setCustomer_name(customer_name);
		
		System.out.println("Enter the contact number");
		int contact_number=sc.nextInt();
		a[i].setContact_number(contact_number);
		
		sc.nextLine();
		System.out.println("enter customer email id");
		String email_id=sc.nextLine();
		a[i].setEmail_id(email_id);
	}
	break;
	case 2:
		for(int i=0;i<a.length;i++)
		{
		System.out.println(a[i].getCustomer_id());
		System.out.println(a[i].getCustomer_name());
		System.out.println(a[i].getContact_number());
		System.out.println(a[i].getEmail_id());
		}
   break;
	case 3:
		System.out.println("exit");
		k=1;
		break;
	}
	}
	
}

	}

