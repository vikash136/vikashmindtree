import java.util.Scanner;
public class AA2
{
	public static void main(String[] args)
	{
		int a[]=new int[6];
		System.out.println("enter the array");
		@SuppressWarnings("resource")
		Scanner sc=new Scanner (System.in);
		for(int i=1;i<6;i++)  
	    {  
	        a[i]=sc.nextInt();  
	    }
	    for(int i=1;i<6;i++)  
	    {  
	        for (int j=1;j<6;j++)  
	        {  
	            if(a[i]<a[j])  
	            {  
	                int temp = a[i];  
	                a[i]=a[j];  
	                a[j] = temp;   
	            }  
	        }  
	    }  
	    System.out.println("Printing Sorted List ...");  
	    for(int i=1;i<6;i++)  
	    {  
	        System.out.print(" "+a[i]);  
	    }  
	}  
	}  
