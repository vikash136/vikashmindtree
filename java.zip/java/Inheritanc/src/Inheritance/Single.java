package Inheritance;

class Animal
{
	void eat()
	{
		System.out.println(" Animal eat");
	}
}
class Dog extends Animal
{
	void bark()
	{
		System.out.println("barking");
	}
}
public class Single {

	public static void main(String[] args)
	{
		Dog d=new Dog();
		d.bark();
		d.eat();
		Animal obj=new Dog();
		obj.eat();
		
		
				

	}

}
