import java.util.Locale;
import java.util.Scanner;

public class Emaze {

	public static void main(String[] args)
	{
		String str;
		String str1="";
		int x=0,y=0;
		Scanner sc=new  Scanner(System.in);
		System.out.println("enter the string");
		str=sc.nextLine();
		String str2=str.toUpperCase();
		char arr[]=str2.toCharArray();
		for(int i=0;i<str2.length();i++)
		{
			if(arr[i]=='L')
			{
				x=x-1;
			}
			else if(arr[i]=='R')
			{
				x=x+1;
			}
			else if(arr[i]=='U')
			{
				y=y+1;
			}
			else if(arr[i]=='D')
			{
					 y=y-1;
			}
		}
		System.out.println(x +" "+y);
				

	}

}
