import java.util.Scanner;
public class AA5 
{
	public static void main(String[] args) 
	{
		System.out.println("enter the number of disk");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Scanner dj=new Scanner(System.in);
		System.out.println(" enter from rod ");
		String A=dj.nextLine();
		System.out.println(" enter to rod ");
		String C=dj.nextLine();
		System.out.println(" enter temp rod ");
		String B=dj.nextLine();
		towerOfHanoi(n,A,C,B);
	}
	 static int towerOfHanoi(int n, String A, String C, String B)
	{
		if(n==1)
		{
			System.out.println(" move disk 1 fron rod "+ A + " to rod " + C);
			return (0);
		}
		towerOfHanoi(n-1,A,B,C);
		System.out.println(" move disk "+ n + " from rod " + A + " to rod " + C);
		towerOfHanoi(n-1,B,C,A);
		return (0);

}
}
