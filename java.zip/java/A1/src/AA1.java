import java.util.Scanner;
public class AA1
{
	public static void main(String[] args)
	{
		int count=0;
		System.out.println("Enter a number:");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		sc.close();
		while(n>0)
		{
			if(n%2==0)
			{
				n=n/2;
				System.out.println(n+ " is even so i take half : "+n);
			}
			else
			{
				n=3*n+1;
				System.out.println(n + " is odd so i make 3n=1 : "+n);
			}
			count++;
			if(n==1)
				break;
		}
	System.out.println("There are total "+count+" steps to reach 1");
	}
}
