import java.util.Scanner;

public class Toggle {
      int a=5;
      float b=5.9f;
	public static void main(String[] args)
	{
		String str;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string");
		str=sc.nextLine();
		char arr[]=str.toCharArray();
		int n=str.length();
		for(int i=0;i<n;i++)
		{
		 if(arr[i]>='a' && arr[i]<='z')
		 {
			 arr[i]= (char) ( arr[i]-32);
		 }
		 else if(arr[i]>='A' && arr[i]<='Z')
		 {
			 arr[i]=(char) (arr[i]+32);
		 }
		}
		System.out.println("final string");
		for(int i=0;i<arr.length;i++)
		{
		System.out.print(arr[i] +" ");
		}
		

	}

}
