import java.util.Scanner;
public class Array
{
	public static void main(String[] args)
	{
		
		int smallSize,bigSize;
		System.out.println("enter the size of first array");
		Scanner sc=new Scanner (System.in);
		int m=sc.nextInt();
		Double a[]=new Double[m];
		System.out.println("enter the elements of first Array");
		for(int i=0;i<m;i++)
		{
			a[i]=sc.nextDouble();
		}
		System.out.println("enter the second size of array");
		int n =sc.nextInt();
		Double b[]=new Double[n];
		System.out.println("enter the elements of second array");
		for(int j=0;j<n;j++)
		{
			b[j]=sc.nextDouble();
		}
		System.out.print("First array: ");
		for(int i=0;i<m;i++)
		{
			System.out.print(a[i]+" ");
		}
		System.out.println();
		System.out.print("2nd aary aaray: ");
		for(int j=0;j<n;j++)
		{
			System.out.print(b[j]+ " ");
		}
		if(a.length>b.length)
		{
			bigSize=a.length;
			smallSize=b.length;
		}
		else
		{
			bigSize=b.length;
			smallSize=a.length;
		}
		
		int sum[]=new int[bigSize];
		for(int i=0;i<smallSize;i++)
		{
			sum[i]=(int) (a[i]+b[i]);
		}
		System.out.println();
		
		for(int i=smallSize;i<bigSize;i++)
		{
			sum[i]=b[i].intValue();
		}
		System.out.println("welcome to Possible");
		for(int i=0;i<bigSize;i++)
		{
			System.out.print(sum[i]+" ");
		}
	}
}
		