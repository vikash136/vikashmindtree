import java.util.Scanner;

public class AA6
{
	public static void main(String[] args) 
	{
		String name,mobile , out ;
		Double feedback;
		int count=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the name");
		name=sc.nextLine();
		System.out.println("enter the your mobile number");
		mobile=sc.nextLine();
		System.out.println("enter the feedback");
		feedback=sc.nextDouble();
		System.out.println("out of");
		out=sc.nextLine();
		System.out.println("maximum number");
		Double feed;
		feed=sc.nextDouble();
		System.out.println(name + ": " + "mobile number is " + mobile + " feedback " + feedback + " out of "  + feed  );
	}

}
