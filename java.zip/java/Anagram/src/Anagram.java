import java.util.Arrays;
import java.util.Scanner;

public class Anagram
{

	public static void main(String[] args) 
	{
		String str1;
	      String str2;
	      Scanner sc =new Scanner(System.in);
	      System.out.println("enter the first string");
	      str1=sc.nextLine();
	      System.out.println("enter the second string");
	      str2=sc.nextLine();
	      System.out.println("first string :- "+ str1);
	      System.out.println("second string :- " +str2 );
	      int count=0;
	      for(int i=0;i<str1.length();i++)
	      {
	    	  for(int j=0;j<str2.length();j++)
	    	  {
	    		  if(str1.charAt(i)==str2.charAt(j))
	    		  {
	    			  count++; 
	    		  }
	    		  else
	    		  {
	    			 
	    		  }
	    		  break;
	    			  
	    	  }
	      }
	      System.out.println(count);
	}
}
