package com.mindtree;

class A
{
	public void show(int a)
	{
		System.out.println("hi");
	}

	public void show( int a,int b)
	{
		System.out.println("hello");
	}
}
public class Poly {

	public static void main(String[] args) 
	{
		A obj=new A();
		obj.show(2,3);
		
	}
}
