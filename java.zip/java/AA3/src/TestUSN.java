import java.util.Scanner;
public class TestUSN 
{
	public static void main(String[] args)
	{
		System.out.println("enter the string");
     Scanner sc=new Scanner(System.in);
     String USN=sc.nextLine();
     sc.close();
    int s=USN.length();
    if(s==10)
    {
    	if(USN.charAt(0)==49||USN.charAt(0)==50)
    	{
    		if(USN.charAt(1)>=65 && USN.charAt(1)<=90 && USN.charAt(2)>=65 && USN.charAt(2)<=90)
    		{
    			if(USN.charAt(3)>=48 && USN.charAt(3)<=57 && USN.charAt(4)>=48 && USN.charAt(4)<=57)
    			{
    				if(USN.charAt(5)==67 || USN.charAt(5)==73 || USN.charAt(5)==69 || USN.charAt(5)==77 && USN.charAt(6)==83  || USN.charAt(6)==67 ||USN.charAt(6)==69)
    				{
    					if(USN.charAt(7)>=48 && USN.charAt(7)<=57 && USN.charAt(8)>=48 && USN.charAt(8)<=57 && USN.charAt(9)>=48 && USN.charAt(9)<=57)
    					{
    						System.out.println("Success");
    					}
    					else
    					{
    					System.out.println("faliure");
    					}
    				}
    				else
    				{
    					System.out.println("faliure");
    				}
    			
    			}
    			else
    			{
    				System.out.println("faliure");
    			}
    		}
    		else
    		{
    			System.out.println("faliure");
    		}
    	}
    	else
    	{
    		System.out.println("faliure");
    	}
    }
    else
    {
    System.out.println("failure");
	}
}
}