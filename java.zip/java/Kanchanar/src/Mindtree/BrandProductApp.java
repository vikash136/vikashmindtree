package Mindtree;

import java.util.Scanner;

public class BrandProductApp
{

	public static void main(String[] args) 
	{
		//create products
		Product[]p1= {new Product(1,"TV",200000),new Product(2,"phone",20000650),new Product(3,"camera",2000600)};
		Product[]p2= {new Product(1,"watch",400000),new Product(2,"Laptop",600000),new Product(3,"Table",500000)};
		
		//create Brand with products
	
		Brand[] brandArr= {new Brand(1, "sony", p1),new Brand(2, "Apple", p2)};
		
		//ask user for a Brand 
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a brand which you want to searc all its products");
		String ip=sc.next();
		Brand res=getBrand(brandArr, ip);
		Product[]result=res.getProducts();
		
		//dispalying products of array
		for(int i=0;i<result.length;i++)
		{
			System.out.println(result[i].getPrice()+" "+result[i].getProductName()+" " );
		}
	}
	//create a method which will return a perticular brand from  list of brands
	static Brand getBrand(Brand[] brrArr,String ip)
	{
		Brand result=new Brand();
		//Brand result=null;
		//some logic
		for(int i=0;i<brrArr.length;i++)
		{
			if(brrArr[i].getBrandName().equals(ip))
					{
						result=brrArr[i];
					}
		}
		return result;
		
	}

}
