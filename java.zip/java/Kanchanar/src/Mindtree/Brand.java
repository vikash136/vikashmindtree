package Mindtree;

public class Brand 
{
	int brandId;
	String brandName;
	Product[] products;
	public Brand()
	{
		
	}
	public Brand(int brandId, String brandName, Product[] products)
	{
		super();
		this.brandId = brandId;
		this.brandName = brandName;
		this.products = products;
	}
	public int getBrandId() {
		return brandId;
	}
	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public Product[] getProducts() {
		return products;
	}
	public void setProducts(Product[] products) {
		this.products = products;
	}
	

}
