package Library;

import java.util.Scanner;

public class LibrarayManagementApp {
	static Scanner sc=new Scanner (System.in);
	public static void main(String[] args)
	{
		
		
		//create book
		System.out.println("Enter book count:");
		int bookcount=sc.nextInt();
		Book [] books=getAllBooks(bookcount);
		
		//create library
				System.out.println("enter library id");
				int libraryId=sc.nextInt();
				Library library=new Library(libraryId,books);
				
		
		for (int i = 0; i < books.length; i++)
		{
			System.out.println(books[i].getBookId() +" "+books[i].getBookName()+" "+books[i].getPrice());
			Author [] auth=books[i].getAuthor();
			for (int x = 0; x < auth.length; x++) 
			{
				System.out.println(auth[x].getAuthorId()+" "+auth[x].getAuthorName());
				
			}
			
		}
		
		//create library
		
	}
	//method to return of books
	private static Book[] getAllBooks(int bookcount)
	{
		Book[]result=new Book[bookcount];
		
		 for (int i = 0; i < bookcount; i++)
		 {
			 
				System.out.println("enter the book id");
				int bookId=sc.nextInt();
				
				System.out.println("enter the bbok name");
				String bookName=sc.next();
				
				System.out.println("enter the book price");
				double bookprice=sc.nextDouble();
				
				System.out.println("enter author count");
				int authorcount=sc.nextInt();
				
				Author[]authors=getAllAuthors(authorcount);
				result[i]=new Book(bookId, bookName, authors, bookprice);
		}
		
		
		return result;
	}
	//method to return of authors
	static Author[] getAllAuthors(int authorcount)
	{
		Author[] authArr =new Author[authorcount];
		
		for (int i = 0; i < authArr.length; i++)
		{
			authArr[i]=new Author();
			
		}
		Author[]result=authArr;
		
		//my logic to override 'result'
		for (int i = 0; i < authArr.length; i++)
		{
			
			System.out.println("enter the id");
			int authId=sc.nextInt();
			
			System.out.println("enter the authoe name");
			String authName=sc.next();
			
			System.out.println("enter the author gender");
			String authGender=sc.next();
			result[i]=new Author(authId,authName,authGender);
		
		}
		return result;
		
	} 
	//method to return female a authors from all authors /libraray
	static Author[]getFemaleAuthors(Library library)
	{
		Author[]result=null;
		int authcount=0;
		//logic to find female authors 
		Book[] books=library.getBook();
		for (int i = 0; i < books.length; i++)
		{
		authcount=authcount+books[i].getAuthor().length;
			
		}
		Author[]allAuthors=new Author[authcount];
		for(int y=0;y<authcount;y++)
		{
		for (int i = 0; i < books.length; i++)
		{
			Author[]allAut=books[i].getAuthor();
			for(int z=0;z<allAut.length;z++)
			{
				allAuthors[y]=allAut[z];
			}
			
		}
		
		for(int i=0;i<allAuthors.length;i++)
		{
			if(allAuthors[i].getGender().equalsIgnoreCase("female"))
					{
						result[i]=allAuthors[i];
					}
					
		}
		return result;
	}
		return allAuthors;
	
	}
}
