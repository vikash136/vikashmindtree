package Library;


public class Library 
{
private int LibraryId; 
private Book[] book;

public Library() {
	
	// TODO Auto-generated constructor stub
}
public Library(int libraryId, Book[] book) {
	super();
	LibraryId = libraryId;
	this.book = book;
	
}
public int getLibraryId() {
	return LibraryId;
}
public void setLibraryId(int libraryId) {
	LibraryId = libraryId;
}
public Book[] getBook() {
	return book;
}
public void setBook(Book[] book) {
	this.book = book;
}



}
