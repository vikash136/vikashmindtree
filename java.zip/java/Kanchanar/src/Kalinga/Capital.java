package Kalinga;

import Mindtree.Product;

public class Capital 
{
	int id;
	String name;
	State[] s2;
	public Capital()
	{
		
	}
	public Capital(int id, String name, State[] s2) 
	{
		super();
		this.id = id;
		this.name = name;
		this.s2 = s2;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public State[] getS2() {
		return s2;
	}
	public void setS2(State[] s2) {
		this.s2 = s2;
	}
	
}
