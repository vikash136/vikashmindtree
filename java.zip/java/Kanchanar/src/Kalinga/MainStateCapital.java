package Kalinga;

import java.util.Scanner;


public class MainStateCapital {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner (System.in);
		//int ch=sc.nextInt();
		State s1[]= {new State(1,"Odisha","Bhubaneswar")};
		State s2[]= {new State(2,"Bihar","Patana")};
		Capital c1[]= {new Capital (1,"Bhubaneswar",s1),new Capital(2,"Patana",s2)};
		System.out.println("Enter a id which you want to searc all states and capital ");
		int  ip=sc.nextInt();
		Capital res=getCapital(c1, ip);
		State[] result=res.getS2();
		for(int i=0;i<result.length;i++)
		{
			System.out.println(result[i].getCapital() +" "+ result[i].getName());
		}
}

	 static Capital getCapital(Capital[] c1, int ip)
	{
		
		Capital result=new Capital();
		for(int i=0;i<c1.length;i++)
		{
			if(c1[i].getId()==ip)
					{
						result=c1[i];
					}
		}
		return result;
	}
}