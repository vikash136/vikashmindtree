package AgainStatecapital;

import java.util.Scanner;

public class StateCapitalApp {

	public static void main(String[] args) 
	{
		
		//create capitals
		Capital c1=new Capital(1,"Bhubaneswar");
		Capital c2=new Capital(2,"Patana");
	
		//create states
		State s1=new State(1, "Odisha", c1);
		State s2=new State(2, "Bihar", c2);
		
		State[]starr= {s1,s2};
		//ask user input  -> stateId
		Scanner sc=new Scanner(System.in);
		System.out.println("enter state id");
		int ip=sc.nextInt();
		
		//calling method 
        State st=getState(starr,ip);
		//print its capital details
        System.out.println(st.getStateName()+" "+st.getCapital().getCapitalName());
		

	}
	private static State getState(State[] st, int ip)
	{
		State result=new State();
		for(int i=0;i<st.length;i++)
		{
			if(ip==st[i].getStateId())
			{
				result=st[i];
			}
		}
		
		return result;
	}

}
