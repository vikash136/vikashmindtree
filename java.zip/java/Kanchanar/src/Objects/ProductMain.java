package Objects;
import java.util.Scanner;
public class ProductMain 
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		
		System.out.println("Enetr no of product to be entered ");
		int n=sc.nextInt();
		Product a[]=new Product[n];
		for(int i=0;i<n;i++)
		{
			a[i]=new Product();
		}
		createProduct(a,n);
		showProduct(n, a);

	}
	private static void createProduct(Product[] a, int n) 
	{
		for(int i=0;i<n;i++)
		{
			System.out.println(" enter id  of "+ i+"th product");
			int id=sc.nextInt();
			a[i].setId(id);//if you make constuctor then not mandarty this set 
			
			System.out.println(" enter name  of "+ i+"th product");
			String name=sc.next();
			a[i].setName(name);
			
			System.out.println(" enter price  of "+ i+"th product");
			double price =sc.nextDouble();
			a[i].setPrice(price);
			
			System.out.println(" enter rating   of "+ i+"th product");
			double rating=sc.nextDouble();
			a[i].setRating(rating);
			
		 // a[i]=new Product(id,name,price,rating);
		}
	}

	private static void showProduct(int n, Product[] a) {
		for(int i=0;i<n;i++)
		{
			System.out.println("Below ");
			System.out.println(a[i].getId()+" "+a[i].getName()+" "+a[i].getPrice()+" "+a[i].getRating()+" ");
		}
	}
	//another way return type
//	Product p1[]=createProduct(a,n);
//	showProduct(n, p1);
//
//}
//private static Product[] createProduct(Product[] a, int n) 
//{
//	for(int i=0;i<n;i++)
//	{
//		System.out.println(" enter id  of "+ i+"th product");
//		int id=sc.nextInt();
//		a[i].setId(id);
//		
//		System.out.println(" enter name  of "+ i+"th product");
//		String name=sc.next();
//		a[i].setName(name);
//		
//		System.out.println(" enter price  of "+ i+"th product");
//		double price =sc.nextDouble();
//		a[i].setPrice(price);
//		
//		System.out.println(" enter rating   of "+ i+"th product");
//		double rating=sc.nextDouble();
//		a[i].setRating(rating);
//		
////	  a[i]=new Product(id,name,price,rating);
//	}
//	return a;
//}
//
//private static void showProduct(int n, Product[] a) {
//	for(int i=0;i<n;i++)
//	{
//		System.out.println("Below ");
//		System.out.println(a[i].getId()+" "+a[i].getName()+" "+a[i].getPrice()+" "+a[i].getRating()+" ");
//	}
//}
//	

}
