package StateCountryUser;

public class State 
{
	private int stateId;
	private String sateName;
	private String Capital;
	
	public State() {
		
		// TODO Auto-generated constructor stub
	}
	public State(int stateId, String sateName, String capital) {
		
		this.stateId = stateId;
		this.sateName = sateName;
		Capital = capital;
	}
	public int getStateId() {
		return stateId;
	}
	public void setStateId(int stateId) {
		this.stateId = stateId;
	}
	public String getSateName() {
		return sateName;
	}
	public void setSateName(String sateName) {
		this.sateName = sateName;
	}
	public String getCapital() {
		return Capital;
	}
	public void setCapital(String capital) {
		Capital = capital;
	}
	
	
	

}
