package StateCountryUser;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner (System.in);
		//create n no of countries by taking n fome user 
		System.out.println("enter the count,  How many countries you want to create ");
		int countryCount=sc.nextInt();
		
		Country[]countryArray=new Country[countryCount];
		
		for (int i = 0; i < countryArray.length; i++) 
		{
			countryArray[i]=new Country();
		}
		
		for (int i = 0; i < countryArray.length; i++) 
		{
			System.out.println("enter country id");
			int countryId=sc.nextInt();
			countryArray[i].setCountryId(countryId);
			
			System.out.println("enter country name");
			String countryName=sc.next();
			countryArray[i].setCountryName(countryName);
			
			System.out.println("how many states you want for the coutry"+countryArray[i].getCountryName());
			int stateCount=sc.nextInt();
			
			//for each county i will create state
			
			State[] states = getAllStateofACountry(sc, stateCount);
			countryArray[i].setStates(states);
			
		}
		//view all state and counties
		for (int i = 0; i < countryArray.length; i++)
		{
			System.out.println(countryArray[i].getCountryId());
			System.out.println(countryArray[i].getCountryName());
			
			State[] states=countryArray[i].getStates();
			
			for (int j = 0; j < countryArray[i].getStates().length; j++)
			{
				System.out.println(states[j].getStateId());
				System.out.println(states[j].getSateName());
				System.out.println(states[j].getCapital());
				
			}
		}
		//i will get state for which i want to chanege the capital
		//i will change capital
	}
	
	private static State[] getAllStateofACountry(Scanner sc, int stateCount) 
	{
		State[] states=new State[stateCount];
		for (int j = 0; j < states.length; j++) 
		{
			states[j]=new State();
		}
		
		for (int j = 0; j < states.length; j++) 
		{
			System.out.println("enter state id");
			int stateId=sc.nextInt();
			states[j].setStateId(stateId);
			
			System.out.println("enter state  name");
			String stateName=sc.next();
			states[j].setSateName(stateName);
			
			System.out.println("enter state capital name");
			String stateCapital=sc.next();
			states[j].setCapital(stateCapital);
		}
		return states;
	}

}
