package Grocery;

public class Grocery 
{
		int potatoQuantity;
		int tomatoQuantity;

		public Grocery()
		{
			System.out.println("default constructor");
		}
		
		public Grocery(int potatoQuantity, int tomatoQuantity) 
		{
			
			this.potatoQuantity = potatoQuantity;
			this.tomatoQuantity = tomatoQuantity;
			System.out.println("parameterized constructor");
		}

		
		public void setPotatoQuantity(int potatoQuantity) 
		{
			this.potatoQuantity = potatoQuantity;
		}

		public void setTomatoQuantity(int tomatoQuantity)
		{
			this.tomatoQuantity = tomatoQuantity;
		}

		public int getPotatoQuantity()
		{
			return potatoQuantity;
		}

		public int getTomatoQuantity()
		{
			return tomatoQuantity;
		}

		public static void main(String[] args)
		{

			Grocery g = new Grocery();
			g.setPotatoQuantity(30);
			System.out.println(g.getPotatoQuantity());
			
			Grocery g1= new Grocery(5, 10);
			System.out.println(g1.getPotatoQuantity());
			System.out.println(g1.getTomatoQuantity());
			g1.setPotatoQuantity(6);
			System.out.println(g1.getPotatoQuantity());
			System.out.println(g1.getTomatoQuantity());
			
		}

	}
