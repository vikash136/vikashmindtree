package EmployeeDepartment;

import java.util.Scanner; 
public class Main {
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) 
	{
		System.out.println("Entert the employee detatils");
		int n=sc.nextInt();
		Employee e1[]=new Employee[n];
		Department d1=new Department ("computer science",e1);
			for(int i=0;i<n;i++)
			{
				e1[i]=new Employee();
			}
			createEmployee(e1,n);
			showEployeeDeatils(e1,n);
		}
	private static void createEmployee(Employee[] e1, int n)
	{

		for(int i=0;i<n;i++)
		{
			System.out.println(" enter  the id of "+(i+1)+" employee  ");
			int employeeId=sc.nextInt();
			
			System.out.println(" enter  the name of "+(i+1)+" employee");
			String employeeName=sc.next();
			
			System.out.println(" enter  the salary of " +(i+1)+" employee ");
			double employeeSalary=sc.nextDouble();
			
			e1[i]=new Employee(employeeId,employeeName,employeeSalary);
			
		}
		
	}
	private static void showEployeeDeatils(Employee[] e1, int n)
	{
		for(int i=0;i<n;i++)
		{
		System.out.println("Employee Id, "+ e1[i].getEmployeeId()+" Employee Name, "+e1[i].getEmployeeName()+" Employee Salary, "+e1[i].getEmployeeSalary());
		}
		Employee ep=new Employee();
		ep=getHighestsal(e1);
		System.out.println(ep.getEmployeeId()+" "+ep.getEmployeeName()+" "+ep.getEmployeeSalary());
	}
	static Employee getHighestsal(Employee[] e)
	{
		Employee res=new Employee();
		double max=e[0].getEmployeeSalary();
		for (int i = 0; i < e.length; i++) 
		{
			if(e[i].getEmployeeSalary()>max)
				max=e[i].getEmployeeSalary();
		}
		for (int i = 0; i < e.length; i++) 
		{
			if(e[i].getEmployeeSalary()==max)
				res=e[i];
		}
		return res;
	}
			
		
	}


