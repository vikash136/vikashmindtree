package EmployeeDepartment;

public class Department 
{
	
	String departmentName;
	Employee[] employee;
	public Department(String string, Employee[] e1)
	{
		// TODO Auto-generated constructor stub
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public Employee[] getEmployee() {
		return employee;
	}
	public void setEmployee(Employee[] employee) {
		this.employee = employee;
	}
	
	

}
