package SelfStateCapital;
public class State 
{
	private int stateId;
	private String stateName;
	private Capital Capital;
	
	public int getStateId() {
		return stateId;
	}
	public void setStateId(int stateId) {
		this.stateId = stateId;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public Capital getCapital() {
		return Capital;
	}
	public void setCapital(Capital capital) {
		Capital = capital;
	}
	

}
