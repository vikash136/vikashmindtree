package SelfStateCapital;

import java.util.Scanner;

public class CapitalStateApp
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enetr the only 2 number ");
		int n=sc.nextInt();
		Capital a[]=new Capital[n];
		for(int i=0;i<n;i++)
		{
			a[i]=new Capital();
		}
		createCapital(a,n);
		showCapital(n, a);
		//for state 
		State b[]=new State[n];
		for(int i=0;i<n;i++)
		{
			b[i]=new State();
		}
		createState(b,n);
		showState(n, b);

	}
	private static void createCapital(Capital[] a, int n) 
	{
		for(int i=0;i<n;i++)
		{
			System.out.println(" enter id ");
			int capitalId=sc.nextInt();
			a[i].setCapitalId(capitalId);
			
			System.out.println(" enter name capital");
			String capitalName=sc.next();
			a[i].setCapitalName(capitalName);
		}
	}
		private static void showCapital(int n, Capital[] a)
		{
		for(int i=0;i<n;i++)
		{
			System.out.println("Below ");
			System.out.println(a[i].getCapitalId()+" "+a[i].getCapitalName()+" ");
		}
			
		}
		private static void createState(State[] b, int n)
		{
			for(int i=0;i<n;i++)
			{
				System.out.println(" enter id ");
				int stateId=sc.nextInt();
				b[i].setStateId(stateId);
				
				System.out.println(" enter state name");
				String stateName=sc.next();
				b[i].setStateName(stateName);
				
				System.out.println("enter the capital name");
				Capital Capital=sc.next();
				b[i].setCapital(capital);
			}
			
		}
		private static void showState(int n, State[] b)
		{
			
			
		}

	

	}


