package SelfStateCapital;

public class Capital 
{
	int capitalId;
	String capitalName;
	
	public Capital()
	{
		
	}
	public int getCapitalId() {
		return capitalId;
	}
	public void setCapitalId(int capitalId) {
		this.capitalId = capitalId;
	}
	public String getCapitalName() {
		return capitalName;
	}
	public void setCapitalName(String capitalName) {
		this.capitalName = capitalName;
	}
	

}
