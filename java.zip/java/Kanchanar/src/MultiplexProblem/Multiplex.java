package MultiplexProblem;

public class Multiplex 
{

	int multiplexId;
	String multiplexName;
	Movie movie;
	public Multiplex()
	{
		
	}
	public Multiplex(int multiplexId, String multiplexName, Movie movie) {
		this.multiplexId = multiplexId;
		this.multiplexName = multiplexName;
		this.movie = movie;
	}
	public int getMultiplexId() {
		return multiplexId;
	}
	public void setMultiplexId(int multiplexId) {
		this.multiplexId = multiplexId;
	}
	public String getMultiplexName() {
		return multiplexName;
	}
	public void setMultiplexName(String multiplexName) {
		this.multiplexName = multiplexName;
	}
	public Movie getMovie() {
		return movie;
	}
	public void setMovie(Movie movie) {
		this.movie = movie;
	}
	
}
