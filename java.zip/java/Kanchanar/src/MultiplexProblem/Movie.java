package MultiplexProblem;

public class Movie
{
	int movieId;
	String movieName;
	double movieRating;
	public Movie(int movieId, String movieName, double movieRating) {
		this.movieId = movieId;
		this.movieName = movieName;
		this.movieRating = movieRating;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public double getMovieRating() {
		return movieRating;
	}
	public void setMovieRating(double movieRating) {
		this.movieRating = movieRating;
	}
	
	

}
