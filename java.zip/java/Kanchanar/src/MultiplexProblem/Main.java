package MultiplexProblem;

import java.util.Scanner;

public class Main
{

	public static void main(String[] args) 
	{

		//create movies
		Movie m1=new Movie(1,"DDLJ",7.6);
		Movie m2=new Movie(2,"Uri Attack",9.2);
		
		//create multiplexes
		Multiplex mp1=new Multiplex(1, "A", m1);
		Multiplex mp2=new Multiplex(2, "B", m2);
		
		//ask userr to enter id
		System.out.println("Enter multiplex id to get the details of movie:");
		Scanner sc=new Scanner(System.in);
		int id=sc.nextInt();
		
		//search multiplexes based on id
		Multiplex[] m= {mp1,mp2};
		Multiplex res=getMultiplex(m,id);
		
		System.out.println("Movie ID:"+res.getMovie().getMovieId()+"\tname:"+res.getMovie().getMovieName()+"\tRating:"+res.getMovie().getMovieRating());
	}

	private static Multiplex getMultiplex(Multiplex[] m, int id)
	{
		Multiplex res=new Multiplex();
		for(int i=0;i<m.length;i++)
		{
			if(id==m[i].getMultiplexId())
			{
				res=m[i];
			}
		}
		return res;
	}

	}

