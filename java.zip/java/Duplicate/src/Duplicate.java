import java.util.Arrays;
import java.util.Scanner;

public class Duplicate {

			public static void main(String[] args)
			{
				Scanner sc=new Scanner (System.in);
				System.out.println("enter the string i am ready");
				String str=sc.nextLine();
				int n=str.length();
				char[] arr1 = str.toCharArray();
		         Arrays.sort(arr1);
				for(int i=0;i<n;i++)
				{
					int count=1;
					while(i<n-1 && arr1 [i]==arr1[i+1])
					{
						count++;
						i++;
					}
					System.out.print(arr1[i]);
					System.out.print(count);
				}
				
			}
		


	}