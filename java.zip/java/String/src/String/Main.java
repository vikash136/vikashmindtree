package String;
import java.util.Scanner;
class A
{
	String rev="";
	public String reverse(String str)
	{
	for(int i= str.length()-1;i>=0;i--)
	{
		
		rev=rev + str.charAt(i);
	}
         System.out.println(rev);
	
		return str;
   }
	
	public void show(String str1) 
	{
		char[] arr=rev.toCharArray();
		
		for(int i=0;i<rev.length();i++)
		{
		if(i%2!=0)
		{
		    arr[i]=Character.toUpperCase(arr[i]);
		}
		else
		{
			arr[i]=Character.toLowerCase(arr[i]);
		}
		}
		System.out.println("string odd even : ");
		for(int i=0;i<arr.length;i++)
		{
		System.out.print(arr[i]);
		}
	}
}
public class Main 
{
	public static void main(String[] args)
	{
		String str;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string : ");
		str=sc.nextLine();
		A obj=new A();
		String str1=obj.reverse(str);
		obj.show(str1);
	}

}
