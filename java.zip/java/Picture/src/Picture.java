import java.util.Scanner;
public class Picture
{
	public static void main(String[] args)
	{
		int w,l,h,n;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number of photo ");
		n=sc.nextInt();
		System.out.println("enter the length ");
		l=sc.nextInt();
		System.out.println("enter the width ");
		w=sc.nextInt();
		System.out.println("enter the hight ");
		h=sc.nextInt();
		System.out.println("photo "+ n+", length "+l+", width "+w+", hight "+h);
		if(n<=1000)
		{
		if(w<l||h<l)
		{
			System.out.println("UPLOAD ANOTHER");
		}
		if(w<=1000&&h<=10000 && w==h&&w==l)
		{
				System.out.println("ACCEPTED");
		}
		else
		{
			System.out.println("CROP IT");
		}
		}
	}
}

	
