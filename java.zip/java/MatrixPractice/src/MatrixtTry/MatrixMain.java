package MatrixtTry;

import java.util.Scanner;

public class MatrixMain 
{
	public static  int[][] add( int r,int c , int[][] a, int[][] b) 
	{
		int result[][]=new int[r][c];
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				result[i][j]=a[i][j]+b[i][j];
			}
		}
		return result;	
	}
	public static void show(int r, int c, int[][] result)
	{
		System.out.println("addition matrix: ");
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				System.out.print(result[i][j] +" ");
			}
			System.out.println();
		}
		
	}
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int r,c;
		System.out.println("Enter the row");
		r=sc.nextInt();
		System.out.println("Enter the column");
		c=sc.nextInt();
		
		if(r==c)
		{
			int a[][]=new int[r][c];
			int b[][]=new int[r][c];
			
			System.out.println(" Enter first matrix  element : ");
			for(int i=0;i<r;i++)
			{
				for(int j=0;j<c;j++)
				{
					a[i][j]=sc.nextInt();
				}
			}
			System.out.println(" Enter the second matrix element : ");
			for(int i=0;i<r;i++)
			{
				for(int j=0;j<c;j++)
				{
					b[i][j]=sc.nextInt();
				}
			}
			System.out.println("show second matrix: ");
			for(int i=0;i<r;i++)
			{
				for(int j=0;j<c;j++)
				{
					System.out.print(a[i][j] +" ");
				}
				System.out.println();
			}
			System.out.println("show second matrix: ");
			for(int i=0;i<r;i++)
			{
				for(int j=0;j<c;j++)
				{
					System.out.print(b[i][j] +" ");
				}
				System.out.println();
			}
			int result[][]=add(r,c,a,b);
			show(r,c,result);
		}
		else
		{
			System.out.println("please insert again because row and column should be same ");
		}
		
	}	
}
