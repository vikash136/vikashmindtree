package MatrixtTryThreeClass;

public class B {

}
