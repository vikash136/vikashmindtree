package Matrix;

import java.util.Scanner;

public class A 
{

	public int[][]sort(int row,int column) 
	{
		int b[][]=new int[row][column];
		Scanner sc=new Scanner(System.in);
		System.out.println(" Enter the element : ");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<column;j++)
			{
				b[i][j]=sc.nextInt();
			}
		}
		return b;		
	}
	public void show(int row,int column,int b[][]  ) 
	{
		System.out.println("show first matrix: ");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<column;j++)
			{
				System.out.print(b[i][j] +" ");
			}
			System.out.println();
		}
	}

}
