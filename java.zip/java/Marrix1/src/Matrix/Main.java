package Matrix;
import java.util.Scanner;
public class Main 
{
	public static void main(String[] args)
	{
		int row,column;
		Scanner sc=new Scanner(System.in);
		System.out.println(" enter the row");
		row=sc.nextInt();
		System.out.println("enter the column :");
		column=sc.nextInt();
		if(row==column)
		{
		A obj =new A();
		int r[][]=obj.sort(row,column);
		obj.show(row,column,r);
		B dj=new B();
		int p[][]=dj.boss(row ,column);
		dj.Display(row ,column,p);
		Swap bj=new Swap();
		bj.swapmulti(row,column, p, r);
		}
		else
		{
			System.out.println("sorry please again try to  enter n*n ");
			
		}
	}
	
}
