package Matrix;

public class Swap {
	public int swapmulti(int row, int column, int b[][], int arr[][]) {
		for (int i = 0; i < row; i++) {
			int temp = b[row - 1][i];
			b[row - 1][i] = arr[row - 1][i];
			arr[row - 1][i] = temp;

		}
		System.out.println("after swap first matrix");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < column; j++) {
				System.out.print(b[i][j] + " ");
			}
			System.out.println("");
		}
		System.out.println("after swap second matrix");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < column; j++) {
				System.out.print(arr[i][j] + " ");
			}
			System.out.println("");
		}
		return column;

	}

}
