package Matrix;

import java.util.Scanner;

public class B
{
		public int[][]boss(int row,int column) 
		{
			int arr[][]=new int[row][column];
			Scanner sc=new Scanner(System.in);
			System.out.println(" Enter the element of second matrix : ");
			for(int i=0;i<row;i++)
			{
				for(int j=0;j<column;j++)
				{
					arr[i][j]=sc.nextInt();
				}
			}
			return arr;
					
		}
		public void Display(int row,int column,int arr[][]  ) 
		{
			System.out.println("show Second matrix: ");
			for(int i=0;i<row;i++)
			{
				for(int j=0;j<column;j++)
				{
					System.out.print(arr[i][j] +" ");
				}
				System.out.println();
			}
		}
	}


