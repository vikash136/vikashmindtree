import java.util.Scanner;

public class Stringspace 
{

	public static void main(String[] args)
	{
		String str;
		int count=0;
		int j=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string");
		str=sc.nextLine();
		char arr[]=str.toCharArray();
		String[] array=str.split(" ");

			for(int i=0;i<arr.length;i++)
			{
				try
				{
				System.out.print(array[i]);
				}
				catch(ArrayIndexOutOfBoundsException e)
				{
					
				}
				}
}
}
