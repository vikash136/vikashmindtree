import java.util.Scanner;

public class BinarySearch
{

	public static void main(String[] args) 
	{
		int num,first,last,middle;
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter the size of : ");
		num=sc.nextInt();
		int array[]=new int[num];
		int item;
		System.out.println("Enter the item which you want to search : ");
		item=sc.nextInt();
		System.out.println("Enter the sorted element  : ");
		for(int i=0;i<num;i++)
		{
			array[i]=sc.nextInt();
		}
		System.out.print(" Array : ");
		for(int i=0;i<num;i++)
		{
			System.out.print(array[i] + " ");
		}
		System.out.println("");
		 first = 0;
	      last = num - 1;
	      middle = (first + last)/2;
	      while( last >=first )
	      {
	         if ( array[middle] == item )
	         {
	           System.out.println( " item " + item + " found at location " + (middle + 1) + ".");
	           break;
	         }
	         else if (item >array[middle] )
	         {
	           first = middle + 1;
	         }
	         else
	         {
	             last = middle - 1;
	         }
	         middle = (first + last)/2;
	      }//end while
	      if ( first > last )
	      {
	          System.out.println(item + " is not found.\n");
	      }
	   }
	}


