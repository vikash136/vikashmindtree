import java.util.Scanner;

public class DuplicateArray {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		 System.out.println("enter the Size of array n ");
		 int n=sc.nextInt();
		 int arr[]=new int[n];
		 System.out.println("enter the element");
		 for(int i=0;i<arr.length;i++)
		 {
			 arr[i]=sc.nextInt();
		 }
	        for (int i = 0; i < arr.length; i++)
	        {
	            for (int j = i+1; j < arr.length; j++) 
	            {
	                if (arr[i] ==arr[j])
	                {
	                   arr[i]='?';
	                   
	                } 
	            }
	        }
	        for(int i=0;i<arr.length;i++)
	        {
	        	if(arr[i]!='?')
	        	{
	        		System.out.println(arr[i]);
	        	}
	        }
	  


	}
}
