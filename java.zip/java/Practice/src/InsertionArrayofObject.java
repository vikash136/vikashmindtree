import java.util.Scanner;
class A
{ int a;//global variable
	public int[] sort(int n) //return array  
	{
		int b[]=new int[n];
		Scanner sc=new Scanner(System.in);
		System.out.println(" Enter the element : ");
		for(int i=0;i<n;i++)
		{
			b[i]=sc.nextInt();
		}
		 for (int i=1; i<n; ++i) 
	      { 
	            int key = b[i]; 
	            int j = i-1; //local variable
	            while (j>=0 && b[j] > key) 
	            { 
	                b[j+1] = b[j]; 
	                j = j-1; 
	            } 
	            b[j+1] = key; 
	      } 
		return b;
	}
	public void show(int n,int b[]) 
	{
		
		System.out.println("insertion sorted array : ");
		for(int i=0;i<n;i++)
		{
			System.out.print(b[i] +" ");
		}
	}
}
public class InsertionArrayofObject 
{
	public static void main(String[] args) 
	{
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println(" enter the array of size");
		n=sc.nextInt();
		A obj =new A();
		try
		{
		int r[]=obj.sort(n);
		obj.show(n,r);
		}
		catch(Exception e)
		{
		}
	}
}



