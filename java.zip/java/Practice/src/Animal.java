public class Boss 
{
	public void eat()
	{
		System.out.println(" Boss eat");
	}
}
class Cat extends Animal
{
	public void eat()
	{
		System.out.println("cat eat");
	}
	public void meow()
	{
		System.out.println("cat meow");
	}
}
class Animal
{
	public static void main(String[]args)
	{
		Cat obj=new Cat();
		obj.eat();
		Animal sc=new Cat();//
		sc.eat();
	Animal dj= new Animal();
		dj.eat();
		obj = (Cat)sc;
		
		//Cat vs=new Animal();
		//vs.eat();
		
		
	}
}