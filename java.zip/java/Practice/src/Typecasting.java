
public class Typecasting 
{
	
	 public static void main(String[]args)
	 {
		 double s =5.5d;
		 int i=(int)s;
		 System.out.println(s);
		 System.out.println(i);
		 char ch = 'c'; 
		    int num = (int)ch; 
		    System.out.println(ch);
		    System.out.println(num);
	 }
} 
	

//	public void eat1()
//	{
//		System.out.println("eat");
//	}
//	
//}
//class B extends Typecasting 
//{
//	public void eat()
//	{
//		System.out.println(" B eat");
//	}
//	public void bark()
//	{
//		System.out.println("bark");
//	}
//	
//}
//class m
//{
//	public static void  main(String []args)
//	{
//		
//	
//
//		
