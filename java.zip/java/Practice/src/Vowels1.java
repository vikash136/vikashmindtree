import java.util.Scanner;

public class Vowels1 
{
	public static void main(String []args)
	{
		String name;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		name=sc.nextLine();
	     String[] word=name.split(" ");
	     String reversename=" ";
	     int i,j;
	     for(i=0;i<word.length;i++)
	     {
	      String str=word[i];
	      String revstr=" ";
	      for(j=str.length()-1;j>=0;j--)
	      {
	         char chr=str.charAt(j) ;
	         revstr=revstr+chr;
	      }
	      reversename =reversename + revstr ;
	    }
	    System.out.println(reversename);
	}
}

