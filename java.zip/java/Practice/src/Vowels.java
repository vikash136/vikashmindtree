import java.util.Scanner;

public class Vowels {

	public static void main(String[] args) 
	 {
			String str,str3="";
			int count=0;
			int max=1;
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the string");
			str=sc.nextLine();
			String[] arr1 = str.split(" ");
		    String str2="";
			for(int i=0;i<arr1.length;i++)
			{
				str2=arr1[i];
				for(int j=0;j<str2.length();j++)
				{
					if(str2.charAt(j)=='a'||str2.charAt(j)=='e'||str2.charAt(j)=='i'||str2.charAt(j)=='o'||str2.charAt(j)=='u')
					{
						count++;
					}
				}
			if(max<=count)
			{
				if(max==count)
				{
					if(str3.length()>str2.length())
					{
						str3=str2+"";
						max=count;
					}
				}
				else
				{
					str3=str2;
					max=count;
				}
				
			}
		     
	     }
			count=0;
		if(str3.isEmpty())
		    {
			System.out.println("no vowel");
			}
		else
		{
			System.out.println(str3);
		}
		
}
}