import java.util.Scanner;

public class Charmatrix {

	public static void main(String[] args) 
	{
		int row = 3;
        int column = 3;
        int digonal=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the string");
         String a;
         a=sc.nextLine();
        char[][] arr = new char[row][column];
        int b[][]= new int [row][column];
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < column; j++)
            {
          
				arr[i][j] = a.charAt(j + i*column);
            }
        }
        System.out.println(" 2d char aaary : ");
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < column; j++)
            {
          
				System.out.print(arr[i][j] +" ");
               
            }
            System.out.println();
        }
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < column; j++)
            {
          
				b[i][j]=(int) arr[i][j];
            }
        
        }
        System.out.println("convert in ASCII value  : ");
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < column; j++)
            {
          
				System.out.print(b[i][j] +" ");
               
            }
            System.out.println();
        }
        System.out.println("Addition of  Digonal:  ");
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < column; j++)
            {
          
				if(i==j)
				{
					digonal = digonal+b[i][j];
				}
            }
        
        }
        System.out.println(digonal);    

	}
}

