import java.util.Scanner;

public class Vowel2 {

	public static void main(String[] args)
	{
		String str,str3="";
		int count=0;
		int max=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		str=sc.nextLine();
		String[] arr1 = str.split(" ");
	    String str2="";
		for(int i=0;i<arr1.length;i++)
		{
			str2=arr1[i];
			if(str2.contains('a'+"")&&str2.contains('e'+"")&&str2.contains('i'+"")&&str2.contains('o'+"")&&str2.contains('u'+""))
			{
				count++;
			}
			if(count>0)
			{
					if(str3.length()>str2.length())
					{
						str3=str2+"";
					}
				
				else
				{
					str3=str2+"";
				}	
			}
			count=0;
		}
		if(str3.length()==0)
		{
			System.out.println("no vowel");
		}
		else
		{
			System.out.println(str3);
		}

	}

}
