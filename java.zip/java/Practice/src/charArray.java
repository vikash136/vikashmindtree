import java.util.Scanner;

public class charArray 
{
	public static void main(String[] args)
	{
		char ch[][]=new char[3][3];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter charecter");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
			char ch1=sc.next().charAt(0);
			}
		}
		System.out.println(" 2d char aaary : ");
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
          
				System.out.print(ch1[i][j]);
               
            }
            System.out.println();
        }
	}

}
