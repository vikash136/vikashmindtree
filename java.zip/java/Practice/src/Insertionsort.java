import java.util.Scanner;

public class Insertionsort
{
	  public static void main(String args[]) 
	    { 
		  int x;
		  Scanner sc=  new Scanner (System.in);
		  System.out.println("enter the size of array : ");
		   x=sc.nextInt();
		  int arr[]=new int[x];
		  System.out.println("Enter the element : ");
		  for(int i=0;i<x;i++)
		  {
			  arr[i]=sc.nextInt();
		  }
		  for (int i=1; i<x; ++i) 
	      { 
	            int key = arr[i]; 
	            int j = i-1; 
	            while (j>=0 && arr[j] > key) 
	            { 
	                arr[j+1] = arr[j]; 
	                j = j-1; 
	            } 
	            arr[j+1] = key; 
	      } 
		  System.out.println(" Inserstion sorted array : ");
		  for (int i=0; i<x; ++i) 
		  {
	            System.out.print(arr[i] + " "); 
	            
	    }
}
}
		  
	
