
public class Variable 
{  
	static int data=50;//global variable 
	  int n=3;
		public static void main(String[] args)
		{ int data=80;
		  int n=34;
//		  System.out.println(n);
//		  System.out.println(data);
//		  System.out.println(new Variable().n);
//		  System.out.println(Variable.data);
		}
//		System.out.println("data");
}
		
class Base
{

	public  static void name(String[] args)
	{
		System.out.println("this is base class");
		System.out.println(new Variable().n);
		System.out.println(Variable.data);
		
	}
}