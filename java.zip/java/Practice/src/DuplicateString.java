import java.util.Scanner;

public class DuplicateString 
{
	public static void main(String[] args)
	{		 
		 Scanner sc=new Scanner(System.in);
		 System.out.println("enter the string");
		 String out="";
		 String str=sc.next();
		 char arr[]=str.toCharArray();
	        for (int i = 0; i < arr.length; i++)
	        {
	            for (int j = i+1; j < arr.length; j++) 
	            {
	                if (arr[i] ==arr[j])
	                {
	                   arr[j]='?';
	                }
	            }
	        }
	        System.out.println(out);
	        for(int i=0;i<arr.length;i++)
	        {
	        	if(arr[i]!='?')
	        		System.out.print(arr[i]);
	        }
	    }
	}
