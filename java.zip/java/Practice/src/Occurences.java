import java.util.Scanner;

public class Occurences {

	public static void main(String[] args)
	{
		   String str;
		   Scanner sc=new Scanner(System.in);
		   System.out.println("enter the string");
		   str=sc.nextLine();
		   int n=str.length();
		   char temp=0;
		   char arr1[]=str.toCharArray();
		  for(int i=0;i<arr1.length;i++)
		  {
			  for(int j=0;j<arr1.length;j++)
			  {
			  if (arr1[j]>arr1[i])
			  {
			         temp = arr1[i];
			        arr1[i] = arr1[j];
			        arr1[j] = temp;
			  }
			 
		  }
		  }  
		  System.out.println("After sorting string : ");
			for(int k=0;k<arr1.length;k++)
			{
			System.out.print(arr1[k]);
			}
			System.out.println();
			System.out.println("final string with count : ");
			for(int i=0;i<n;i++)
			{
				int count=1;
				while(i<n-1 && arr1 [i]==arr1[i+1])
				{
					count++;
					i++;
				}
				System.out.println("Number of Occurrence of " +arr1[i] +" is: "+count);
			}
	}

	}


