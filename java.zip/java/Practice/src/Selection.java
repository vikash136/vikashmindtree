import java.util.Scanner;

public class Selection {

	public static void main(String[] args)
	{
		int n;
		@SuppressWarnings("resource")
		Scanner sc=  new Scanner (System.in);
		  System.out.println("enter the size of array : ");
		   n=sc.nextInt();
		  int arr[]=new int[n];
		  System.out.println("Enter the element : ");
		  for(int i=0;i<n;i++)
		  {
			  arr[i]=sc.nextInt();
		  }
		  for (int i = 0; i < n-1; i++) 
	        { 
	            int min_idx = i; 
	            for (int j = i+1; j < n; j++) 
	            {
	                if ( arr[min_idx] >arr[j]) 
	                {
	                    min_idx = j; 
	                }
	            int temp = arr[min_idx]; 
	            arr[min_idx] = arr[i]; 
	            arr[i] = temp;
	            }
	        }
		  System.out.println(" sorted array :");
		  for(int i=0;i<n;i++)
		  {
			  System.out.print(arr[i] +" ");
		  }
	}

}
