import java.util.Scanner;

public class Switch
{
	public static void main(String[] args)
	{
		int number;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		number=sc.nextInt();
	    switch(number)
	    {  
	    case 10:
	    {
	    	System.out.println("10");  
	    	break;  
	    }
	    case 20: 
	    	{
	    		System.out.println("20");  
	    		break; 
	    	}
	    case 30:
	    	{
	    		System.out.println("30");  
	    		break; 
	    	}
	    default:
	    	{
	    		System.out.println("sorry "); 
	    	}
	    }  

}
}
