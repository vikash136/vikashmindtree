import java.util.Scanner;

public class Distinict {

	public static void main(String[] args)
	{
		int n,k;
		Scanner sc=new Scanner (System.in);
		System.out.println("enter the size of aaray");
		n=sc.nextInt();
		System.out.println("enter the number  ");
		k=sc.nextInt();
		int a[]=new int[n];
		System.out.println("enter the array element");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		int count = 0;
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]+a[j]==k||a[j]+a[i]==k)
				{
					count++;
				}
			}
		}
		System.out.println("Count of pairs with given add is " + count);
		
		
	}

}
