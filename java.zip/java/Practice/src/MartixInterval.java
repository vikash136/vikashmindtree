import java.util.Scanner;

public class MartixInterval 
{
	public static void main(String[] args) 
	{
		int row;
        int column;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the row :");
        row=sc.nextInt();
        System.out.println("enter the column :");
        column=sc.nextInt();
        int b[]=new int[row*column];
        int c=0;
        int k1=0,l=0;
        int a[][]  = new int[row][column];
        System.out.println(" enter the element");
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < column; j++)
            {
				a[i][j]=sc.nextInt();
            }
        }
        System.out.println(" 2d char aaary : ");
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < column; j++)
            {
          
				System.out.print(a[i][j] +" "); 
            }
            System.out.println();
        }
//        System.out.println ("\nConverted to a 1D array: ");
//        for(int i=0;i<row;i++)
//        {	
//        for(int j=0;j<column;j++)
//        {
//        b[c]=a[i][j];
//        System.out.print(b[c] +" ");
//        c++;        
//        }
//        }
        for(int i=0;i<row;i++)
        {
        	for(int j=0;j<column;j++)
        	{
        	if(c%2==0)
        	{
        		k1=k1+a[i][j];
        		c--;
        	}
        	else
        	{
        		l=l+a[i][j];
        		c--;
        	}
        	}
        }
        System.out.println("odd position addition "+l+", even position Addtion "+k1);
       
	}
}
