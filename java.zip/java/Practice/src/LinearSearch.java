import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args)
	{
		int n,flag=0;
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter the size of : ");
		n=sc.nextInt();
		int x[]=new int[n];
		int s;
		System.out.println("Enter the item which you want to search : ");
		s=sc.nextInt();
		System.out.println("Enter the element : ");
		for(int i=0;i<n;i++)
		{
			x[i]=sc.nextInt();
		}
		System.out.print(" Array : ");
		for(int i=0;i<n;i++)
		{
			System.out.print(x[i] + " ");
		}
		for(int i=0;i<n;i++)
		{
			if(x[i]==s)
			{
				flag=1;
				break;
			}
			else
			{
				flag=0;
			}
		}
		System.out.println("");
		  if(flag != 0)  
		    {  
		        System.out.println("Item found at location :" + flag);  
		    }  
		    else
		    {
		        System.out.println(" Item not found ");  
		        
		    }
	}

}
