package micro;

import java.util.Scanner;
public class MainApp 
{ 
	static Scanner sc=new Scanner (System.in);
	public static void main(String[] args)
	{
		MainApp ca =new MainApp();
		College []carr = ca.carr(ca);
		arrayInsertion(carr);
		facultyDataStartingWithI(carr);
		ca.bubbleSort(carr);
		ca.insertionsort(carr);
		ca.updateAge(carr);
		ca.deleteAge(carr);
		
		
	}//close main method

	private College[]carr(MainApp ca)
	{
		System.out.println("enter the count,  How many college you want to create");
		int cn=sc.nextInt();
		College c[]=new College[cn];
		for(int i=0;i<c.length;i++)
		{
			System.out.println(" enter  the id of "+(i+1)+" college  ");
			int collegeId=sc.nextInt();

			System.out.println(" enter  the name of "+(i+1)+" college");
			String collegeName=sc.next();
			
			Department []departmentData=ca.departmentData(ca);
			College c1=new College (collegeId,collegeName,departmentData);
			c[i]=c1;
		}
		return c;
	}
	private Department[] departmentData(MainApp ca)
	{
		System.out.println("enter the count,  How many department you want to create");
		int dn=sc.nextInt();
		Department[] d=new Department[dn];
		for (int j = 0; j< d.length; j++) 
		{
			System.out.println(" enter  the id of "+(j+1)+" Department ");
			int departmentId=sc.nextInt();

			System.out.println(" enter  the name of "+(j+1)+" Department");
			String departmentName=sc.next();
			
			Faculty []facultyData=facultyData();
			Department d1=new Department(departmentId,departmentName,facultyData);
			d[j]=d1;
			
		}
		return d;	
	}
	
	private Faculty[]facultyData()
	{
		System.out.println("enter the count,  How many faculty you want to create");
		int fn=sc.nextInt();
		Faculty f[]=new Faculty[fn];
		for (int k = 0; k <fn; k++)
		{
				System.out.println(" enter  the id of "+(k+1)+" Faculty ");
				int facultyId=sc.nextInt();

				System.out.println(" enter  the name of "+(k+1)+" Faculty");
				String facultyName=sc.next();
				
				System.out.println(" enter  the age of "+(k+1)+" Faculty ");
				int facultyAge=sc.nextInt();
				
				Faculty f1=new Faculty(facultyId,facultyName,facultyAge);
				f[k]=f1;
		
	         }
		return f;
	}
		//college details
		private static void arrayInsertion(College[] carr)
		{
			for(College cd: carr)
			{
				System.out.println(cd);
			}
				
		}
		
		//starrt with i
		private static void facultyDataStartingWithI(College []carr ) 
		{
			int count=0;
			for (int j = 0; j < carr.length-1; j++)
			{
				Department[] departments=carr[j].getDepartment();
				for (int i = 0; i < departments.length-1; i++)
				{
					if(departments[j].getDepartmentName().startsWith("i"))
					{
						count++;
					}
				}
				
			
			System.out.println(count);
			for (int i=0;i<count;i++) 
			{
				System.out.println(departments[i].getDepartmentName());
				
			}
			
		}
		}//end start with i
		
		//deleting
		private void deleteAge(College[] carr)
		{
			System.out.println(" for the deleting ");
			System.out.println("enter the college id");
			int clg=sc.nextInt();
			System.out.println("enter the department id");
			int department=sc.nextInt();
			System.out.println("enter  the faculty id but old id should be same");
			int fac=sc.nextInt();
			for (int i = 0; i < carr.length; i++)
			{
				if(carr[i].getDepartment()[i].getFaculty()[i].getFacultyId()==fac)
				{
	System.out.println("your previous faculty data" +" " +carr[i].getDepartment()[i].getFaculty()[i].getFacultyId()+""
	+carr[i].getDepartment()[i].getFaculty()[i].getFacultyName()+""+carr[i].getDepartment()[i].getFaculty()[i].getFacultyAge());
				
				carr[i].getDepartment()[i].getFaculty()[i].setFacultyId(0);
				carr[i].getDepartment()[i].getFaculty()[i].setFacultyName(null);
				carr[i].getDepartment()[i].getFaculty()[i].setFacultyAge(0);
				
					System.out.println("after deleting  faculty data "+carr[i].getDepartment()[i].getFaculty()[i].getFacultyId()+""
                                     +carr[i].getDepartment()[i].getFaculty()[i].getFacultyName()+""+
							       carr[i].getDepartment()[i].getFaculty()[i].getFacultyAge());
					
				}//if end
				else
				{
					System.out.println("please insert again  because old faculty id and new id should be same");
				}
				
			}
		}
		//updating 
		private void updateAge(College[] carr) 
		{
			
			System.out.println(" for the updateing ");
			System.out.println("enter the college id");
			int clg=sc.nextInt();
			System.out.println("enter the department id");
			int department=sc.nextInt();
			System.out.println("enter the faculty id but old id should be same");
			int fac=sc.nextInt();
			System.out.println("enter the new age");
			int newAge=sc.nextInt();
			
			for (int i = 0; i < carr.length-1; i++)
			{
				if(carr[i].getDepartment()[i].getFaculty()[i].getFacultyId()==fac)
				{
					System.out.println("old age"+carr[i].getDepartment()[i].getFaculty()[i].getFacultyAge());
					carr[i].getDepartment()[i].getFaculty()[i].setFacultyAge(newAge);
					
					System.out.println("updated age"+carr[i].getDepartment()[i].getFaculty()[i].getFacultyAge());
				}
				else
				{
					System.out.println("please insert again because  old faculty id and new id should be same");
				}
				
			}
			
			
		}
		//bubble sorting
		private void bubbleSort(College[] carr)
		{
			System.out.println(" o/p bubble sort");
			System.out.println();
			for (int i = 0; i < carr.length-1; i++)
			{
				for (int j = i+1; j < carr.length-1; j++) 
				{
					if(carr[i].getDepartment()[i].getFaculty()[i].getFacultyAge()> 
					carr[i].getDepartment()[j].getFaculty()[j].getFacultyAge())
					{
						College fac=carr[i];
						carr[i]=carr[j];
						carr[j]=fac;
					}
					
				}
				
			}
			for (int i = 0; i < carr.length-1; i++)
			{
				System.out.println(carr[i].getDepartment()[i].getFaculty()[i].getFacultyId()+" "+carr[i].getDepartment()[i].getFaculty()[i].getFacultyName()+" "
			+carr[i].getDepartment()[i].getFaculty()[i].getFacultyAge());
				
			}
		}
		//insertion sorting
		private void insertionsort(College[] carr)
		{
			System.out.println("o/p insertion sort");
			boolean flag=false;
			System.out.println("");
			
			for (int j = 1; j < carr.length-1; j++)
			{
				College key=carr[j];
				int i=j-1;
				while((i>0)&&(carr[i].getCollegeName().compareTo(carr[j].getCollegeName()))>0)
				{
					carr[i+1]=carr[i];
					i--;
				}
				
				
			}
			for (int i = 0; i < carr.length-1; i++) 
			{
				System.out.println(carr[i].getCollegeId()+" "+carr[i].getCollegeName()+" "+carr[i].getDepartment()[i].getDepartmentName()+
			" "+carr[i].getDepartment()[i].getFaculty()[i].getFacultyName());
				
			}
		}

		}//main app close 
