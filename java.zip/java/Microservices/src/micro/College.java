package micro;

import java.util.Arrays;

public class College 
{
	private int collegeId;
	private String collegeName;
	Department[] department;
	public College() 
	{
		
		// TODO Auto-generated constructor stub
	}
	public College(int collegeId, String collegeName, Department[] department)
	{
		super();
		this.collegeId = collegeId;
		this.collegeName = collegeName;
		this.department = department;
	}
	public int getCollegeId() {
		return collegeId;
	}
	public void setCollegeId(int collegeId) {
		this.collegeId = collegeId;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	public Department[] getDepartment() {
		return department;
	}
	public void setDepartment(Department[] d1) {
		this.department = department;
	}
	@Override
	public String toString() 
	{
		return "College [collegeId=" + collegeId + ", collegeName=" + collegeName + ", department="
				+ Arrays.toString(department) + "]";
	}
	public Faculty[] facultyData() {
		// TODO Auto-generated method stub
		return null;
	}
	public Department[] departData(Faculty[] facultyData) {
		// TODO Auto-generated method stub
		return null;
	}
	public void setFacultyAge(int newAge) {
		// TODO Auto-generated method stub
		
	}
	
	

}
