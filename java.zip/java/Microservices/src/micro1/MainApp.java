package micro1;

import java.util.Scanner;

public class MainApp {

	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) 
	{
		MainApp ca=new MainApp();
		Faculty fc[]=ca.facultyData();
		Department de[]=ca.departmentData(ca);
		College co[]=ca.collegeData(ca);
	}
	
		private College[] collegeData(MainApp ca)
		{
		System.out.println("enter the college data");
		int n=sc.nextInt();
		College []c1=new College [n];
		for (int i = 0; i < c1.length; i++)
		{
			System.out.println("Enter the college id");
			int collegeId=sc.nextInt();
			c1[i].setCollegeId(collegeId);
			
			System.out.println("Enter the college name");
			String collegeName=sc.next();
			c1[i].setCollegeName(collegeName);
			
			Department []dData=departmentData(ca);
			c1[i]=new College(collegeId, collegeName, dData);	
		}
		return c1;
		}

		private Department[] departmentData(MainApp ca)
		{
			
			
			System.out.println("enter the how faculty you want");
			int dn=sc.nextInt();
			Department d1[]=new Department[dn];
			for (int i = 0; i < d1.length; i++) 
			{
				System.out.println("enter the department id");
				int departmentId=sc.nextInt();
				d1[i].setDepartmentId(departmentId);
				

				System.out.println("Enter the department name");
				String departmentName=sc.next();
				d1[i].setDepartmentName(departmentName);
				
				Faculty[] fdata=facultyData();
			    d1[i]=new Department(departmentId, departmentName, fdata)	;
			}
			return d1;
			
	    }
	private Faculty[] facultyData() 
	{
			System.out.println("Enter the faculty of size");
			int n=sc.nextInt();
			Faculty []f1=new Faculty[n];
			for (int i = 0; i < n; i++)
			{
			System.out.println("enter the faculty id");
			int facultyId=sc.nextInt();
			f1[i].setFacultyId(facultyId);
			
			System.out.println("Enter the faculty name");
			String facultyName=sc.next();
			f1[i].setFacultyName(facultyName);
			
			System.out.println("Enter the faculty age");
			int facultyAge=sc.nextInt();
			
			 f1[i]=new Faculty(facultyId,facultyName,facultyAge);
			
	        }
			return f1;	
	}
	}


