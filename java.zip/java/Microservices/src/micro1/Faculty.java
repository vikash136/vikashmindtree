package micro1;

public class Faculty 
{
	private int facultyId;
	private String facultyName;
	private int facultyAge;
	public Faculty(int facultyId, String facultyName, int facultyAge) {
		super();
		this.facultyId = facultyId;
		this.facultyName = facultyName;
		this.facultyAge = facultyAge;
	}
	public Faculty() {
		
		// TODO Auto-generated constructor stub
	}
	public int getFacultyId() {
		return facultyId;
	}
	public void setFacultyId(int facultyId) {
		this.facultyId = facultyId;
	}
	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	public int getFacultyAge() {
		return facultyAge;
	}
	public void setFacultyAge(int facultyAge) {
		this.facultyAge = facultyAge;
	}
	@Override
	public String toString() {
		return "Faculty [facultyId=" + facultyId + ", facultyName=" + facultyName + ", facultyAge=" + facultyAge + "]";
	}
	

}
