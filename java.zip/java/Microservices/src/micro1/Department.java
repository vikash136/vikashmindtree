package micro1;

import java.util.Arrays;

import micro.Faculty;

public class Department
{
	private int departmentId;
	private String  departmentName;
	Faculty[] faculty;
	public Department() {
		
		// TODO Auto-generated constructor stub
	}
	public Department(int departmentId, String departmentName, Faculty[] faculty) {
		super();
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.faculty = faculty;
	}
	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public Faculty[] getFaculty() {
		return faculty;
	}
	public void setFaculty(Faculty[] faculty) {
		this.faculty = faculty;
	}
	@Override
	public String toString() 
	{
		return "Department [departmentId=" + departmentId + ", departmentName=" + departmentName + ", faculty="
				+ Arrays.toString(faculty) + "]";
	}

}
