package ass12;
import java.util.Scanner;
public class mindtree12 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner (System.in);
		System.out.println("enter the string i am ready");
		String str=sc.nextLine();
		int n=str.length();
		String s=str.toLowerCase();
		for(int i=0;i<n;i++)
		{
			int count=1;
			while(i<n-1 && s.charAt(i)==s.charAt(i+1))
			{
				count++;
				i++;
			}
			
			System.out.print(s.charAt(i));
			System.out.print(count);
		}
		
	}
}
