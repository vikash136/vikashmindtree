import java.util.Scanner;

class Customers
{
	
}

class Order  
{
	
public class Main
{

	public void main(String[] args) 
	{
	}
	}
}
		