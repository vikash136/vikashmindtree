import java.util.Arrays;
import java.util.Scanner;

public class Twostring {

	public static void main(String[] args) 
	{
	String str1,str2;
	Scanner sc=new Scanner (System.in);
	System.out.println("enter the first string");
	str1=sc.nextLine();
	System.out.println("enter the secon string");
	str2=sc.nextLine();
	char arr1[]=str1.toCharArray();
	char arr2[]=str2.toCharArray();
	for(int i=0;i<str1.length();i++)
	{
		
	}

}
}
