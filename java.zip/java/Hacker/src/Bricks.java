import java.util.Scanner;

public class Bricks
{
	public static void main(String[] args) 
	{
		int i,j;
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the numbe");
		n=sc.nextInt();
		for(i=1;i<n;i++)
		{
			
		   for(i=i*2;i>n;i++)
		   {
			   
		   }
		}
	
		

	}

}
