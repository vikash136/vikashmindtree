import java.util.Scanner;

public class Findproduct 
{

	public static void main(String[] args)
	{
		int n;
		int answer=1;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the number");
		n=sc.nextInt();
		for(int i=1;i<=n;i++)
		{
			
			answer = (int) ((answer * i)%( Math.pow(10,9) + 7));
		}
		System.out.println(answer);
	}

}
