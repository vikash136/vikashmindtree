import java.util.Scanner;
public class AA9 
{
		public static void printTriplet(int [] a)
		{
			for(int i=0;i<a.length;i++)
			{
			System.out.println(a[i] + " ");
			}
			for(int i=0;i<a.length;i++)
			{
				for(int j=i+1;j<a.length;j++)
				{
					for(int k=j+1;k<a.length;k++)
					{
						if(a[i]==a[j]+a[k]||a[j]==a[i]+a[k]||a[k]==a[i]+a[j])
						{
						System.out.println(a[i] + " , " + a[j] + " ," + a[k] + " ");
					}
					
				}
			}
			
			
		}

	}
static class main
{
	public static void main(String []args)
	{
		AA9 obj =new AA9();
		Scanner sc=new Scanner(System.in);
		int n;
		System.out.println("enter the size of aaray");
		n=sc.nextInt();
		int a[]=new int[n];
		
		System.out.println("enter the aaray");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		obj.printTriplet(a);
	}
}
}
